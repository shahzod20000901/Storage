#!/usr/bin/env python3
"""
FastAPI server for receiving camera data from api.davomat.mv
"""
from fastapi import FastAPI, HTTPException, Request, Depends, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict
from typing import Optional, List, Union
import asyncio
import asyncpg
import yaml
from urllib.parse import quote
import logging
import os
import json
from typing import Dict, Any, Optional

# Logging setup
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Database connection - environment variable dan o'qish
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    "postgresql+asyncpg://chirchiq:shahzod2707@localhost:5432/chirchiq"
)

# Redis configuration (ixtiyoriy)
REDIS_URL = os.getenv("REDIS_URL", "redis://localhost:6379/0")
REDIS_CHANNEL = os.getenv("REDIS_CHANNEL", "davomat:camera:events")

# Davomat API configuration (ixtiyoriy)
DAVOMAT_API_URL = os.getenv("DAVOMAT_API_URL", "http://localhost:8001")
DAVOMAT_RELOAD_ENDPOINT = os.getenv("DAVOMAT_RELOAD_ENDPOINT", "/api/cameras/reload")

# go2rtc.yaml fayl yo'li
GO2RTC_YAML_PATH = "go2rtc.yaml"
ENABLED_CAMERAS_PATH = "enabled_cameras.txt"

app = FastAPI(title="Camera API", version="1.0.0")


# 422 Validation Error handler
@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    """422 Validation Error ni batafsil log qilish"""
    errors = exc.errors()
    body = await request.body()
    
    logger.error(f"❌ Validation Error: {request.method} {request.url.path}")
    logger.error(f"   Request body: {body.decode('utf-8') if body else 'Empty'}")
    logger.error(f"   Validation errors: {errors}")
    
    return JSONResponse(
        status_code=422,
        content={
            "message": "Validation error",
            "status": False,
            "data": {
                "errors": errors,
                "body": body.decode('utf-8') if body else None
            }
        }
    )


# CORS middleware - barcha domainlar uchun ochiq
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# Request logging middleware
@app.middleware("http")
async def log_requests(request: Request, call_next):
    """Barcha so'rovlarni log qilish"""
    client_ip = get_client_ip(request)
    logger.info(f"📥 {request.method} {request.url.path} - {client_ip}")
    logger.info(f"   Headers: {dict(request.headers)}")
    
    # Request body ni log qilish (faqat POST/PUT uchun)
    if request.method in ["POST", "PUT", "PATCH"]:
        try:
            body = await request.body()
            if body:
                try:
                    import json
                    body_json = json.loads(body.decode('utf-8'))
                    logger.info(f"   Request body: {body_json}")
                except:
                    logger.info(f"   Request body (raw): {body[:500]}")
        except Exception as e:
            logger.warning(f"   Request body o'qib bo'lmadi: {e}")
    
    response = await call_next(request)
    
    logger.info(f"📤 {request.method} {request.url.path} - Status: {response.status_code}")
    
    return response


# ================================================================================
# PYDANTIC SCHEMAS
# ================================================================================
class CameraCreate(BaseModel):
    """Kamera yaratish uchun schema"""
    model_config = ConfigDict(populate_by_name=True)
    
    ip: str = Field(..., description="Kamera IP manzili")
    login: Optional[str] = Field(None, description="Kamera login")
    password: Optional[str] = Field(None, description="Kamera parol")
    branchId: int = Field(..., description="Filial ID")
    camera_type: Optional[Union[int, str]] = Field("dahua", description="Kamera turi (dahua/hikvision yoki 1=dahua, 2=hikvision)")


class CameraUpdate(BaseModel):
    """Kamera yangilash uchun schema"""
    ip: Optional[str] = None
    login: Optional[str] = None
    password: Optional[str] = None
    branchId: Optional[int] = None
    camera_type: Optional[str] = None


class CameraResponse(BaseModel):
    """Kamera javob schema"""
    id: int
    ip: str
    login: Optional[str] = None
    password: Optional[str] = None
    branchId: int
    camera_type: Optional[str] = "dahua"
    is_active: Optional[bool] = True


# ================================================================================
# DATABASE HELPERS
# ================================================================================
def parse_db_url(url: str):
    """Database URL dan connection parametrlarini ajratib olish"""
    url_parts = url.replace("postgresql+asyncpg://", "").split("@")
    auth = url_parts[0].split(":")
    host_port_db = url_parts[1].split("/")
    host_port = host_port_db[0].split(":")
    
    return {
        'user': auth[0],
        'password': auth[1],
        'host': host_port[0],
        'port': int(host_port[1]) if len(host_port) > 1 else 5432,
        'database': host_port_db[1]
   }


async def get_db_connection():
    """Database connection olish"""
    db_params = parse_db_url(DATABASE_URL)
    conn = await asyncpg.connect(**db_params)
    return conn


def get_client_ip(request: Request) -> str:
    """Get client IP address"""
    forwarded = request.headers.get("X-Forwarded-For")
    if forwarded:
        return forwarded.split(",")[0].strip()
    return request.client.host if request.client else "unknown"


def success_response(message: str, data=None):
    """Create success response following global API standard"""
    return {
        "message": message,
        "status": True,
        "data": data
    }


def error_response(message: str, data=None):
    """Create error response following global API standard"""
    return {
        "message": message,
        "status": False,
        "data": data
    }


# ================================================================================
# DAVOMAT TIZIMINI YANGILASH
# ================================================================================
async def notify_davomat_system(event_type: str = "add", camera_id: Optional[int] = None):
    """
    Davomat tizimini yangilash - Redis yoki API endpoint orqali
    
    Args:
        event_type: "add" yoki "update"
        camera_id: Kamera ID (ixtiyoriy)
    """
    # Variant 1: Redis kanal orqali
    try:
        import redis.asyncio as redis
        redis_client = redis.from_url(REDIS_URL)
        event_data = {
            "type": event_type,
            "camera_id": camera_id,
            "timestamp": asyncio.get_event_loop().time()
        }
        # JSON formatida yuborish
        await redis_client.publish(REDIS_CHANNEL, json.dumps(event_data))
        await redis_client.aclose()
        logger.info(f"✅ Redis kanalga xabar yuborildi: {event_data}")
        return True
    except ImportError:
        logger.warning("Redis kutubxonasi o'rnatilmagan, Redis variant o'tkazib yuborildi")
    except Exception as e:
        logger.warning(f"Redis xatolik: {e}")
    
    # Variant 2: Davomat API endpoint orqali
    try:
        import requests
        reload_url = f"{DAVOMAT_API_URL}{DAVOMAT_RELOAD_ENDPOINT}"
        response = requests.post(reload_url, timeout=5)
        if response.status_code == 200:
            logger.info(f"✅ Davomat API ga reload so'rovi yuborildi: {reload_url}")
            return True
        else:
            logger.warning(f"⚠️ Davomat API reload so'rovi muvaffaqiyatsiz: {response.status_code}")
    except ImportError:
        logger.warning("requests kutubxonasi o'rnatilmagan, API variant o'tkazib yuborildi")
    except Exception as e:
        logger.warning(f"Davomat API xatolik: {e}")
    
    return False


# ================================================================================
# KAMERA QO'SHISH FUNKSIYASI
# ================================================================================
async def add_camera_to_db(
    ip: str,
    branch_id: int,
    login: Optional[str] = None,
    password: Optional[str] = None,
    camera_type: Optional[str] = None
) -> Dict[str, Any]:
    """
    Kamera ma'lumotlarini bazaga yozish
    
    Args:
        ip: Kamera IP manzili
        branch_id: Filial ID
        login: Kamera login (default: 'admin')
        password: Kamera parol (default: 'admin123')
        camera_type: Kamera turi (default: 'dahua')
    
    Returns:
        Dict: {
            "success": bool,
            "message": str,
            "data": dict yoki None,
            "camera_id": int yoki None
        }
    
    Unikallik qoidasi:
    - branchId = 0: IP barcha kameralar ichida unikal bo'lishi kerak
    - branchId != 0: IP faqat o'sha branchId ichida unikal bo'lishi kerak
    """
    conn = None
    try:
        conn = await get_db_connection()
        
        # Default qiymatlar
        login = login or 'admin'
        password = password or 'admin123'
        
        # camera_type ni integer ga o'girish (1=dahua, 2=hikvision)
        camera_type_int = 1  # default: dahua
        if camera_type:
            if isinstance(camera_type, int):
                camera_type_int = camera_type
            elif isinstance(camera_type, str):
                camera_type_lower = camera_type.lower()
                if camera_type_lower == 'hikvision' or camera_type_lower == '2':
                    camera_type_int = 2
                else:
                    camera_type_int = 1  # dahua yoki default
        
        # IP unikallik tekshiruvi
        if branch_id == 0:
            # branchId = 0: IP barcha kameralar ichida unikal bo'lishi kerak
            existing = await conn.fetchrow(
                "SELECT id FROM cameras WHERE ip = $1",
                ip
            )
        else:
            # branchId != 0: IP faqat o'sha branchId ichida unikal bo'lishi kerak
            existing = await conn.fetchrow(
                "SELECT id FROM cameras WHERE ip = $1 AND \"branchId\" = $2",
                ip,
                branch_id
            )
        
        if existing:
            # Kamera mavjud
            logger.info(f"⚠️ IP {ip} bilan kamera mavjud (id={existing['id']}, branchId={branch_id})")
            return {
                "success": False,
                "message": "Ushbu qurilma mavjud",
                "data": None,
                "camera_id": existing['id']
            }
        
        # Yangi kamera yaratish
        # Bazada faqat quyidagi ustunlar mavjud: ip, login, password, branchId, camera_type
        camera_id = await conn.fetchval("""
            INSERT INTO cameras (ip, login, password, "branchId", camera_type)
            VALUES ($1, $2, $3, $4, $5)
            RETURNING id
        """, ip, login, password, branch_id, camera_type_int)
        
        # Yangi kamera ma'lumotlarini o'qish
        camera = await conn.fetchrow(
            "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras WHERE id = $1",
            camera_id
        )
        
        logger.info(f"✅ Yangi kamera qo'shildi: id={camera_id}, ip={ip}, branchId={branch_id}, camera_type={camera_type_int}")
        
        # camera_type ni string ga o'girish (response uchun)
        camera_type_str = "dahua" if camera['camera_type'] == 1 else "hikvision"
        
        return {
            "success": True,
            "message": "Kamera muvaffaqiyatli qo'shildi",
            "data": {
                "id": camera['id'],
                "ip": camera['ip'],
                "login": camera['login'],
                "password": camera['password'],
                "branchId": camera['branchId'],
                "camera_type": camera_type_str  # String formatda qaytarish
            },
            "camera_id": camera_id
        }
        
    except Exception as e:
        logger.error(f"❌ Kamera qo'shishda xatolik: {e}", exc_info=True)
        return {
            "success": False,
            "message": f"Ichki server xatosi: {str(e)}",
            "data": None,
            "camera_id": None
        }
    finally:
        if conn:
            await conn.close()


# ================================================================================
# SYNC GO2RTC YAML
# ================================================================================
async def sync_go2rtc_yaml():
    """
    Bazadan kameralarni o'qib, go2rtc.yaml va enabled_cameras.txt ni yangilaydi
    """
    conn = None
    try:
        conn = await get_db_connection()
        
        # Bazadan barcha kameralarni o'qish
        # Bazada faqat quyidagi ustunlar mavjud: id, ip, login, password, branchId, camera_type
        rows = await conn.fetch("""
            SELECT 
                id, 
                ip, 
                login, 
                password, 
                "branchId",
                camera_type
            FROM cameras
            ORDER BY ip
        """)
        
        if not rows:
            logger.warning("Bazadan hech qanday kamera topilmadi")
            return
        
        # go2rtc.yaml yaratish
        config = {
            'api': {
                'listen': ':1984'
            },
            'rtsp': {
                'listen': ':8554'
            },
            'streams': {}
        }
        
        camera_ids = []
        
        for row in rows:
            ip = row['ip']
            login = row.get('login') or 'admin'
            password = row.get('password') or 'admin123'
            port = 554  # Default port
            stream_type = 'sub'  # Default: substream
            channel = 1  # Default channel
            camera_type_int = row.get('camera_type', 1)  # 1=dahua, 2=hikvision
            
            # Camera ID: IP ni underscore bilan almashtirish
            camera_id = ip.replace('.', '_')
            camera_ids.append(camera_id)
            
            # Login va password ni URL encode qilish
            login_encoded = quote(login)
            password_encoded = quote(password)
            
            # RTSP URL yaratish (camera_type ga qarab)
            if camera_type_int == 2:  # Hikvision
                # Hikvision main stream: /Streaming/Channels/101
                rtsp_url = f"rtsp://{login_encoded}:{password_encoded}@{ip}:{port}/Streaming/Channels/101"
            else:  # Dahua (1 yoki default)
                # Dahua main stream: subtype=0
                rtsp_url = f"rtsp://{login_encoded}:{password_encoded}@{ip}:{port}/cam/realmonitor?channel={channel}&subtype=0"
            
            config['streams'][camera_id] = rtsp_url
            
            logger.debug(f"Stream qo'shildi: {camera_id} → {rtsp_url}")
        
        # go2rtc.yaml ga yozish
        with open(GO2RTC_YAML_PATH, 'w') as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
        
        # enabled_cameras.txt faylga YOZILMAYDI - faqat foydalanuvchi tomonidan ko'rsatilgan kameralar saqlanadi
        logger.info(f"✅ go2rtc.yaml yangilandi: {len(camera_ids)} ta kamera")
        logger.info(f"ℹ️  enabled_cameras.txt fayli o'zgartirilmaydi (faqat foydalanuvchi tomonidan ko'rsatilgan kameralar saqlanadi)")
        
    except Exception as e:
        logger.error(f"❌ go2rtc.yaml ni yangilashda xatolik: {e}", exc_info=True)
    finally:
        if conn:
            await conn.close()


# ================================================================================
# AUTHENTICATION
# ================================================================================
API_KEY = "your-api-key-here"  # TODO: Environment variable dan o'qish

async def verify_api_key(request: Request):
    """API key tekshiruvi"""
    # Authorization header dan token olish
    auth_header = request.headers.get("Authorization")
    if auth_header:
        # Bearer token format: "Bearer <token>"
        if auth_header.startswith("Bearer "):
            token = auth_header.replace("Bearer ", "")
            if token == API_KEY:
                return True
    
    # X-API-Key header dan olish
    api_key = request.headers.get("X-API-Key")
    if api_key == API_KEY:
        return True
    
    # Agar API key kerak bo'lmasa (development uchun)
    # return True
    
    return False


# ================================================================================
# API ENDPOINTS
# ================================================================================
@app.post("/api/camera/add", status_code=200)
@app.post("/api/cameras/", status_code=200)
@app.post("/api/v1/cameras/", status_code=200)
async def create_camera(
    camera_data: CameraCreate,
    request: Request,
):
    """
    Yangi kamera qo'shish yoki mavjud kamerani yangilash
    
    api.davomat.mv dan keladigan POST so'rovlarni qabul qiladi
    
    Endpoints:
    - POST /api/camera/add (api.davomat.mv uchun)
    - POST /api/cameras/ (alternativ)
    - POST /api/v1/cameras/ (v1 API uchun)
    
    IP unikallik qoidasi:
    - branchId = 0: IP barcha kameralar ichida unikal bo'lishi kerak
    - branchId != 0: IP faqat o'sha branchId ichida unikal bo'lishi kerak
    """
    client_ip = get_client_ip(request)
    
    # Request headers va body ni log qilish (debug uchun)
    logger.info(f"Request headers: {dict(request.headers)}")
    logger.info(f"Request body: {camera_data.model_dump()}")
    
    # camera_type ni string ga o'girish (agar int bo'lsa)
    camera_type_str = None
    if camera_data.camera_type is not None:
        if isinstance(camera_data.camera_type, int):
            # 1 = dahua, 2 = hikvision
            camera_type_str = "dahua" if camera_data.camera_type == 1 else "hikvision"
        else:
            camera_type_str = str(camera_data.camera_type).lower()
    
    logger.info(
        f"Kamera qo'shish so'rovi qabul qilindi {client_ip} dan: "
        f"ip={camera_data.ip}, branchId={camera_data.branchId}, "
        f"camera_type={camera_data.camera_type} → {camera_type_str}"
    )
    
    # Kamera qo'shish funksiyasini chaqirish
    result = await add_camera_to_db(
        ip=camera_data.ip,
        branch_id=camera_data.branchId,
        login=camera_data.login,
        password=camera_data.password,
        camera_type=camera_type_str
    )
    
    if not result["success"]:
        # Kamera mavjud yoki xatolik
        return {
            "message": result["message"],
            "status": False,
            "data": result["data"]
        }
    
    # go2rtc.yaml ni yangilash
    await sync_go2rtc_yaml()
    
    # Davomat tizimini yangilash (ixtiyoriy)
    await notify_davomat_system(event_type="add", camera_id=result["camera_id"])
    
    return {
        "message": result["message"],
        "status": True,
        "data": result["data"]
    }


@app.get("/api/cameras/")
async def list_cameras(branchId: Optional[int] = None):
    """
    Barcha kameralarni olish
    branchId bo'yicha filterlash mumkin
    """
    conn = None
    try:
        conn = await get_db_connection()
        
        if branchId is not None:
            rows = await conn.fetch(
                "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras WHERE \"branchId\" = $1 ORDER BY ip",
                branchId
            )
        else:
            rows = await conn.fetch(
                "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras ORDER BY ip"
            )
        
        cameras_data = [
            {
                "id": row['id'],
                "ip": row['ip'],
                "login": row['login'],
                "password": row['password'],
                "branchId": row['branchId'],
                "camera_type": "dahua" if row['camera_type'] == 1 else "hikvision",  # Integer → string
            }
            for row in rows
        ]
        
        return {
            "message": "Kameralar muvaffaqiyatli yuklandi",
            "status": True,
            "data": {"items": cameras_data, "count": len(cameras_data)}
        }
        
    except Exception as e:
        logger.error(f"Kameralarni yuklashda xatolik: {e}", exc_info=True)
        error_resp = error_response(
            message="Ichki server xatosi",
            data={"error": str(e)}
        )
        raise HTTPException(status_code=500, detail=error_resp)
    finally:
        if conn:
            await conn.close()


@app.get("/api/cameras/{camera_id}")
async def get_camera(camera_id: int):
    """ID bo'yicha kamera ma'lumotlarini olish"""
    conn = None
    try:
        conn = await get_db_connection()
        
        camera = await conn.fetchrow(
            "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras WHERE id = $1",
            camera_id
        )
        
        if not camera:
            error_resp = error_response(
                message="Kamera topilmadi",
                data=None
            )
            raise HTTPException(status_code=404, detail=error_resp)
        
        # camera_type ni string ga o'girish (response uchun)
        camera_type_str = "dahua" if camera['camera_type'] == 1 else "hikvision"
        
        return {
            "message": "Kamera ma'lumotlari muvaffaqiyatli yuklandi",
            "status": True,
            "data": {
                "id": camera['id'],
                "ip": camera['ip'],
                "login": camera['login'],
                "password": camera['password'],
                "branchId": camera['branchId'],
                "camera_type": camera_type_str,
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Kamera ma'lumotlarini olishda xatolik: {e}", exc_info=True)
        error_resp = error_response(
            message="Ichki server xatosi",
            data={"error": str(e)}
        )
        raise HTTPException(status_code=500, detail=error_resp)
    finally:
        if conn:
            await conn.close()


@app.put("/api/cameras/{camera_id}")
async def update_camera(camera_id: int, camera_data: CameraUpdate):
    """Kamera ma'lumotlarini yangilash"""
    conn = None
    try:
        conn = await get_db_connection()
        
        # Kamerani topish
        camera = await conn.fetchrow(
            "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras WHERE id = $1",
            camera_id
        )
        
        if not camera:
            error_resp = error_response(
                message="Kamera topilmadi",
                data=None
            )
            raise HTTPException(status_code=404, detail=error_resp)
        
        # IP unikallik tekshiruvi (agar IP o'zgartirilayotgan bo'lsa)
        if camera_data.ip is not None and camera_data.ip != camera['ip']:
            branch_id = camera_data.branchId if camera_data.branchId is not None else camera['branchId']
            
            if branch_id == 0:
                existing = await conn.fetchrow(
                    "SELECT id FROM cameras WHERE ip = $1 AND id != $2",
                    camera_data.ip,
                    camera_id
                )
            else:
                existing = await conn.fetchrow(
                    "SELECT id FROM cameras WHERE ip = $1 AND \"branchId\" = $2 AND id != $3",
                    camera_data.ip,
                    branch_id,
                    camera_id
                )
            
            if existing:
                error_resp = error_response(
                    message="Ushbu IP manzil allaqachon ishlatilmoqda",
                    data=None
                )
                raise HTTPException(status_code=400, detail=error_resp)
        
        # Update fields
        update_fields = []
        update_values = []
        param_num = 1
        
        if camera_data.ip is not None:
            update_fields.append(f"ip = ${param_num}")
            update_values.append(camera_data.ip)
            param_num += 1
        
        if camera_data.login is not None:
            update_fields.append(f"login = ${param_num}")
            update_values.append(camera_data.login)
            param_num += 1
        
        if camera_data.password is not None:
            update_fields.append(f"password = ${param_num}")
            update_values.append(camera_data.password)
            param_num += 1
        
        if camera_data.branchId is not None:
            update_fields.append(f"\"branchId\" = ${param_num}")
            update_values.append(camera_data.branchId)
            param_num += 1
        
        if camera_data.camera_type is not None:
            update_fields.append(f"camera_type = ${param_num}")
            update_values.append(camera_data.camera_type)
            param_num += 1
        
        if update_fields:
            update_values.append(camera_id)
            query = f"UPDATE cameras SET {', '.join(update_fields)} WHERE id = ${param_num}"
            await conn.execute(query, *update_values)
        
        # go2rtc.yaml ni yangilash
        await sync_go2rtc_yaml()
        
        # Yangilangan kamera ma'lumotlarini o'qish
        updated_camera = await conn.fetchrow(
            "SELECT id, ip, login, password, \"branchId\", camera_type FROM cameras WHERE id = $1",
            camera_id
        )
        
        logger.info(f"Kamera yangilandi: id={camera_id}, ip={updated_camera['ip']}")
        
        # camera_type ni string ga o'girish (response uchun)
        camera_type_str = "dahua" if updated_camera['camera_type'] == 1 else "hikvision"
        
        return {
            "message": "Kamera muvaffaqiyatli yangilandi",
            "status": True,
            "data": {
                "id": updated_camera['id'],
                "ip": updated_camera['ip'],
                "login": updated_camera['login'],
                "password": updated_camera['password'],
                "branchId": updated_camera['branchId'],
                "camera_type": camera_type_str,
            }
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Kamerani yangilashda xatolik: {e}", exc_info=True)
        error_resp = error_response(
            message="Ichki server xatosi",
            data={"error": str(e)}
        )
        raise HTTPException(status_code=500, detail=error_resp)
    finally:
        if conn:
            await conn.close()


@app.delete("/api/cameras/{camera_id}", status_code=200)
async def delete_camera(camera_id: int):
    """Kamerani o'chirish"""
    conn = None
    try:
        conn = await get_db_connection()
        
        camera = await conn.fetchrow(
            "SELECT id, ip FROM cameras WHERE id = $1",
            camera_id
        )
        
        if not camera:
            error_resp = error_response(
                message="Kamera topilmadi",
                data=None
            )
            raise HTTPException(status_code=404, detail=error_resp)
        
        # Kamerani o'chirish (DELETE)
        await conn.execute(
            "DELETE FROM cameras WHERE id = $1",
            camera_id
        )
        
        # go2rtc.yaml ni yangilash
        await sync_go2rtc_yaml()
        
        logger.info(f"Kamera o'chirildi (deactivated): id={camera_id}, ip={camera['ip']}")
        
        return {
            "message": "Kamera muvaffaqiyatli o'chirildi",
            "status": True,
            "data": None
        }
        
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Kamerani o'chirishda xatolik: {e}", exc_info=True)
        error_resp = error_response(
            message="Ichki server xatosi",
            data={"error": str(e)}
        )
        raise HTTPException(status_code=500, detail=error_resp)
    finally:
        if conn:
            await conn.close()


@app.get("/")
async def root():
    """Root endpoint"""
    return {
        "message": "Camera API Server",
        "status": True,
        "data": {
            "version": "1.0.0",
            "endpoints": {
                "POST /api/camera/add": "Yangi kamera qo'shish (api.davomat.mv uchun)",
                "POST /api/cameras/": "Yangi kamera qo'shish (alternativ)",
                "POST /api/v1/cameras/": "Yangi kamera qo'shish (v1 API)",
                "GET /api/cameras/": "Barcha kameralarni olish",
                "GET /api/cameras/{id}": "Kamera ma'lumotlarini olish",
                "PUT /api/cameras/{id}": "Kamerani yangilash",
                "DELETE /api/cameras/{id}": "Kamerani o'chirish"
            }
        }
    }


@app.get("/health")
async def health_check():
    """Health check endpoint"""
    return {
        "message": "Server is running",
        "status": True,
        "data": {
            "status": "healthy"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
