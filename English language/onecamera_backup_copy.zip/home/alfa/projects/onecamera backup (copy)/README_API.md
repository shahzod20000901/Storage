# Camera API Server

Bu server `api.davomat.mv` dan keladigan kamera ma'lumotlarini qabul qiladi va bazaga yozadi.

## Muammo: 403 Forbidden

Agar frontend dan `api.davomat.mv` ga so'rov yubarilganda 403 Forbidden xatolik chiqsa, bu quyidagi sabablarga ko'ra bo'lishi mumkin:

1. **Server ishlamayapti** - API server ishga tushirilmagan
2. **Reverse proxy muammosi** - `api.davomat.mv` bizning serverimizga ulashilmagan
3. **Authentication muammosi** - Token yoki API key noto'g'ri

## Qanday ishlaydi

1. Frontend `https://api.davomat.mv/api/camera/add` ga POST so'rov yubaradi
2. `api.davomat.mv` serveri (reverse proxy) bizning serverimizga (`localhost:8000`) so'rovni yuboradi
3. Bizning serverimiz so'rovni qabul qiladi va bazaga yozadi
4. `go2rtc.yaml` va `enabled_cameras.txt` avtomatik yangilanadi

## Server ishga tushirish

```bash
source venv/bin/activate
python api_server.py
```

Yoki:

```bash
./start_api_server.sh
```

## Test qilish

```bash
curl -X POST http://localhost:8000/api/camera/add \
  -H "Content-Type: application/json" \
  -d '{
    "ip": "192.168.1.10",
    "login": "admin",
    "password": "admin123",
    "branchId": 4,
    "camera_type": "dahua"
  }'
```

## Endpoints

- `POST /api/camera/add` - Yangi kamera qo'shish
- `POST /api/cameras/` - Alternativ endpoint
- `GET /api/cameras/` - Barcha kameralarni olish
- `GET /api/cameras/{id}` - Kamera ma'lumotlarini olish
- `PUT /api/cameras/{id}` - Kamerani yangilash
- `DELETE /api/cameras/{id}` - Kamerani o'chirish
- `GET /health` - Health check

## Bazadagi jadval strukturasini tekshirish

Agar bazada `login` yoki `username` ustunlari bo'lsa, kod ikkalasini ham qo'llab-quvvatlaydi.

Agar `stream_type`, `channel`, `port` ustunlari bo'lmasa, default qiymatlar ishlatiladi.
