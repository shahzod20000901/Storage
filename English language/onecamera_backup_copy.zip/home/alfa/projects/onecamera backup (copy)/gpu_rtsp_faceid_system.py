import cv2
import time
import requests
import traceback
import asyncio
import subprocess
import sys
import torch
from ultralytics import YOLO
from multiprocessing import Process

# ================================================================================
# CONFIG
# ================================================================================
#RTSP_TEMPLATE = "rtsp://localhost:8554/{camera_id}"
RTSP_TEMPLATE = "rtsp://10.70.85.14:8554/{camera_id}"

FACEID_API_URL = "http://172.254.254.50:8002"
FACEID_USERNAME = "admin"
FACEID_PASSWORD = "123456"

HISOBOT_API_URL = "http://api.davomat.mv"
HISOBOT_USERNAME = "QQIModer"
HISOBOT_PASSWORD = "123"
HISOBOT_BRANCH_ID = 4
HISOBOT_TOKEN_TTL = 20 * 3600  # 20 soat (standartga mos)

MIN_CONF = 0.5
FACE_MIN_SIZE = 50  # Uzoqroqda ham shaxsni aniqlash uchun kamaytirildi (80 -> 50)
# Odam yo'qolgan deb hisoblash timeout'i (FPS past kameralar uchun biroz yuqoriroq)
PERSON_LOST_TIMEOUT = 3.0

FACEID_REFRESH_TIME = 50 * 60
HISOBOT_REFRESH_TIME = HISOBOT_TOKEN_TTL - 3600  # 19 soat (20 soatdan 1 soat oldin)

FACEID_SEND_INTERVAL = 0.3  # Shaxs aniqlash tezligini oshirish uchun kamaytirildi (0.5 dan 0.3 ga)
MAX_RETRY = 15

# OPTIMIZATION PARAMETERS
# Shaxs aniqlash tezligi va GPU yuklamasi muvozanati (177 kamera)
FRAME_SKIP = 2  # Har 2 frameda bir marta detection (shaxs aniqlash tezligini oshirish: 3 -> 2)
MODEL_SHARING = True  # Model sharing yoqilgan (GPU memory tejash)
PROCESSING_WIDTH = 800  # Frame processing width (shaxs aniqlash sifati uchun: 640 -> 800)
PROCESSING_HEIGHT = 450  # Frame processing height (shaxs aniqlash sifati uchun: 360 -> 450)
USE_HALF_PRECISION = True  # FP16 precision (GPU yuklamasini ~50% kamaytiradi)
TRACKING_INFERENCE_INTERVAL = 3  # Tracking mode da har 3-frameda inference (shaxs aniqlash tezligini oshirish: 5 -> 3)

# Faol (sog'lom) GPU indekslari.
# Masalan, nvidia-smi logida GPU 2 va 3 da ERR! bo'lsa, faqat [0, 1] ni ishlatamiz.
GPU_IDS = [0, 1, 2, 3, 4, 5]

# Birinchi shaxs aniqlangach, keyingi shaxsni qayta yuborishga ruxsat berish uchun cooldown (soniya).
# Shu vaqt o'tgach already_sent = False bo'ladi, ketma-ket kelgan barcha shaxslar aniqlanadi.
NEXT_PERSON_COOLDOWN = 1.0


# ================================================================================
# TOKEN FUNCTIONS
# ================================================================================
def faceid_login(max_retries=3, retry_delay=2):
    """
    FaceID API ga login qilish va token olish (retry logic bilan)
    
    Args:
        max_retries: Maksimal qayta urinishlar soni
        retry_delay: Qayta urinishlar orasidagi kutish vaqti (sekund)
    
    Returns:
        Token string yoki None (xatolik bo'lsa)
    """
    for attempt in range(max_retries):
        try:
            r = requests.post(
                f"{FACEID_API_URL}/api/v1/auth/login",
                json={"username": FACEID_USERNAME, "password": FACEID_PASSWORD},
                timeout=10
            )
            
            if r.status_code == 200:
                print("🔑 FaceID token olingan")
                return r.json()["access_token"]
            elif r.status_code == 500:
                # Server xatolik - qayta urinish
                if attempt < max_retries - 1:
                    print(f"⚠️ FaceID API 500 xatolik, {retry_delay}s dan keyin qayta urinilmoqda ({attempt + 1}/{max_retries})...")
                    time.sleep(retry_delay)
                    continue
                else:
                    print(f"❌ FaceID API 500 xatolik, {max_retries} urinishdan keyin ham muvaffaqiyatsiz")
                    return None
            else:
                r.raise_for_status()
        except requests.exceptions.RequestException as e:
            if attempt < max_retries - 1:
                print(f"⚠️ FaceID login xatolik: {e}, {retry_delay}s dan keyin qayta urinilmoqda ({attempt + 1}/{max_retries})...")
                time.sleep(retry_delay)
                continue
            else:
                print(f"❌ FaceID login muvaffaqiyatsiz ({max_retries} urinishdan keyin): {e}")
                return None
    
    return None


def hisobot_login():
    """
    Hisobot API ga login qilish va token olish
    
    Returns:
        Token string yoki None (xatolik bo'lsa)
    """
    try:
        url = f"{HISOBOT_API_URL}/api/login"
        payload = {
            "username": HISOBOT_USERNAME,
            "password": HISOBOT_PASSWORD
        }
        
        r = requests.post(url, json=payload, timeout=5)
        
        if r.status_code == 200:
            data = r.json()
            
            # Response format: {"message": "...", "status": true, "data": "token"}
            if data.get("status") and data.get("data"):
                token = data.get("data")
                token_preview = (token[:8] + "…") if token and len(token) > 8 else "…"
                print(f"🔑 [{HISOBOT_API_URL}] Hisobot token olingan: {token_preview} (keyingi yangilanish: 20 soatdan keyin)")
                return token
            else:
                print(f"❌ Hisobot login failed: Invalid response format - {data}")
                return None
        else:
            print(f"❌ Hisobot login failed: {r.status_code} - {r.text[:200]}")
            return None
            
    except Exception as e:
        print(f"❌ Hisobot login error: {e}")
        return None


# ================================================================================
# API CALLS
# ================================================================================
def send_to_faceid(token, crop, camera_id):
    if not token:
        print(f"⚠️ [{camera_id}] FaceID token yo'q - so'rov yuborilmaydi")
        return None
    
    # JPEG sifatini oshirish (quality=95) - yaxshiroq sifati uchun
    encode_params = [cv2.IMWRITE_JPEG_QUALITY, 95]
    _, buf = cv2.imencode(".jpg", crop, encode_params)

    files = {"file": ("frame.jpg", buf.tobytes(), "image/jpeg")}
    data = {"camera_id": camera_id, "timestamp": int(time.time())}
    headers = {"Authorization": f"Bearer {token}"}

    try:
        r = requests.post(
            f"{FACEID_API_URL}/api/v1/faceid/recognize/upload",
            files=files, data=data, headers=headers, timeout=10
        )
    except Exception as e:
        print(f"❌ [{camera_id}] FaceID API so'rov xatosi: {e}")
        return None

    # Status code log
    if r.status_code == 401:
        print(f"🔐 [{camera_id}] FaceID API: 401 Unauthorized - token yangilash kerak")
        return {"error": "unauthorized"}

    if r.status_code != 200:
        try:
            error_body = r.text[:500] if r.text else "Empty response"
            print(f"⚠️ [{camera_id}] FaceID API: Status {r.status_code}")
            print(f"   Response: {error_body}")
        except:
            print(f"⚠️ [{camera_id}] FaceID API: Status {r.status_code} (javob o'qib bo'lmadi)")
        return None

    try:
        response_json = r.json()
        # API javobini to'liq log qilish
        status = response_json.get("status", "unknown")
        message = response_json.get("message", "No message")
        
        # Debug: to'liq javobni ko'rsatish
        print(f"🔍 [{camera_id}] FaceID API javob: status={status}, message={message}")
        if "data" in response_json:
            data = response_json.get("data")
            if isinstance(data, dict):
                if "person" in data:
                    person = data.get("person", {})
                    print(f"   └─ ✅ Shaxs ma'lumotlari mavjud: {list(person.keys())}")
                else:
                    print(f"   └─ ⚠️ data mavjud, lekin 'person' yo'q: {list(data.keys())}")
            else:
                print(f"   └─ data mavjud, lekin dict emas: {type(data)}")
        
        return response_json
    except Exception as e:
        print(f"❌ [{camera_id}] FaceID API javob JSON parse xatosi: {e}")
        print(f"   Raw response: {r.text[:300]}")
        return None


def send_to_hisobot(token, jshshir, camera_id, retry_with_new_token=True):
    """
    Hisobot API ga davomat ma'lumotini yuborish (standartga mos)
    
    Args:
        token: Access token
        jshshir: Person JSHShIR
        camera_id: Camera IP address
        retry_with_new_token: 401 bo'lsa yangi token bilan qayta urinish
        
    Returns:
        Response dict yoki None (xatolik bo'lsa)
    """
    if not token:
        print(f"❌ [{camera_id}] Hisobot: token yo'q")
        return None
    
    try:
        url = f"{HISOBOT_API_URL}/api/hisobot/add"
        
        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }
        
        # IP formatni to'g'rilash: 192_168_1_211 -> 192.168.1.211
        camera_ip = camera_id.replace("_", ".") if "_" in camera_id else camera_id
        
        payload = {
            "ip": camera_ip,
            "jshshir": jshshir,
            "branchId": HISOBOT_BRANCH_ID
        }
        
        # Log: so'rov body formatida
        print(f"📡 Hisobot API so'rov body (JSON):")
        print(f"   {payload}")
        
        r = requests.post(url, headers=headers, json=payload, timeout=5)
        
        if r.status_code == 200:
            response_data = r.json()
            
            # Response format: {"message": "...", "status": true, "data": null}
            if response_data.get("status"):
                default_message = "Ma'lumot yuborildi"
                message = response_data.get('message', default_message)
                print(f"✅ Hisobot API javob: {message}")
                print(f"   └─ IP: {camera_ip}, JSHShIR: {jshshir}, BranchID: {HISOBOT_BRANCH_ID}")
                return response_data
            else:
                error_message = response_data.get('message', 'Xatolik')
                print(f"⚠️ Hisobot API: {error_message}")
                print(f"   └─ IP: {camera_ip}, JSHShIR: {jshshir}")
                return response_data
                
        elif r.status_code == 403:
            # 403 Forbidden = ruxsat yo'q (token to'g'ri bo'lishi mumkin, lekin bu amalga ruxsat berilmaydi)
            print(f"⚠️ Hisobot API 403 Forbidden – ma'lumot rad etildi")
            print(f"   Javob: {r.text[:200]}")
            print(f"   Endpoint: {url}, body: ip={camera_ip}, jshshir={jshshir}, branchId={HISOBOT_BRANCH_ID}")
            print(f"   Token yangilanmaydi (403 odatda token muammosi emas, balki filial/ruxsat tekshiruvi)")
            return None
            
        elif r.status_code == 401:
            # 401 Unauthorized = token eski/noto'g'ri – yangi token olib qayta urinamiz
            if retry_with_new_token:
                print(f"🔄 Hisobot API 401, yangi token olinmoqda va qayta yuborilmoqda...")
                new_token = hisobot_login()
                if new_token:
                    # Yangi token bilan qayta urinish
                    return send_to_hisobot(new_token, jshshir, camera_id, retry_with_new_token=False)
                else:
                    print(f"❌ Hisobot: yangi token olish muvaffaqiyatsiz")
                    return {"error": "unauthorized"}
            else:
                print(f"❌ Hisobot API 401: qayta urinish ham muvaffaqiyatsiz")
                return {"error": "unauthorized"}
        else:
            error_body = r.text[:500] if r.text else "Empty response"
            print(f"⚠️ Hisobot API request failed: {r.status_code} - {error_body}")
            print(f"   URL: {url}")
            return None
            
    except requests.exceptions.Timeout:
        print(f"⚠️ Hisobot API request timeout (IP: {camera_ip}, JSHShIR: {jshshir})")
        return None
    except Exception as e:
        print(f"❌ Hisobot API request error (IP: {camera_ip}, JSHShIR: {jshshir}): {e}")
        return None


# ================================================================================
# FRAME RESIZE FUNCTION (GPU Optimization)
# ================================================================================
def resize_frame_for_processing(frame):
    """
    Frame resolutionni kamaytirish GPU yuklamasini kamaytiradi.
    Original frame crop uchun saqlanadi.
    """
    if PROCESSING_WIDTH is None or PROCESSING_HEIGHT is None:
        return frame, 1.0, 1.0
    
    h, w = frame.shape[:2]
    
    # Agar frame allaqachon kichik bo'lsa, resize qilmaymiz
    if w <= PROCESSING_WIDTH and h <= PROCESSING_HEIGHT:
        return frame, 1.0, 1.0
    
    # Aspect ratio ni saqlab qolish
    scale_w = PROCESSING_WIDTH / w
    scale_h = PROCESSING_HEIGHT / h
    scale = min(scale_w, scale_h)
    
    new_w = int(w * scale)
    new_h = int(h * scale)
    
    # INTER_AREA interpolation - kamaytirish uchun yaxshiroq va tezroq
    resized = cv2.resize(frame, (new_w, new_h), interpolation=cv2.INTER_AREA)
    return resized, scale, scale


# ================================================================================
# CROP QUALITY FUNCTION
# ================================================================================
def crop_quality_face(frame, box, enlarge=0.4):
    """
    Yuzdan crop olish va sifati tekshirish.
    enlarge parametri oshirildi (0.25 -> 0.4) - ko'proq kontekst va yaxshiroq sifati uchun.
    """
    x1, y1, x2, y2 = box
    h, w, _ = frame.shape

    bw, bh = x2 - x1, y2 - y1
    ex = int(bw * enlarge)
    ey = int(bh * enlarge)

    nx1 = max(0, x1 - ex)
    ny1 = max(0, y1 - ey)
    nx2 = min(w, x2 + ex)
    ny2 = min(h, y2 + ey)

    crop = frame[ny1:ny2, nx1:nx2]

    # Blur filter - threshold kamaytirildi (25 -> 15) - ko'proq crop qabul qilinadi
    # Lekin juda past sifati crop'larni rad etish uchun saqlanadi
    gray = cv2.cvtColor(crop, cv2.COLOR_BGR2GRAY)
    fm = cv2.Laplacian(gray, cv2.CV_64F).var()
    if fm < 15:  # 25 dan 15 ga kamaytirildi - ko'proq crop qabul qilinadi
        return None

    # Crop resolution tekshirish - juda kichik crop'larni rad etish
    crop_h, crop_w = crop.shape[:2]
    if crop_w < 100 or crop_h < 100:  # Minimal crop o'lchami
        return None

    # Crop sifati yaxshilash - agar crop juda kichik bo'lsa, biroz kattalashtirish
    # (FaceID API ga yaxshiroq sifati uchun)
    min_crop_size = 200  # Minimal crop o'lchami (yaxshiroq sifati uchun)
    if crop_w < min_crop_size or crop_h < min_crop_size:
        # Crop'ni kattalashtirish (bicubic interpolation - yaxshiroq sifati)
        scale = max(min_crop_size / crop_w, min_crop_size / crop_h)
        new_w = int(crop_w * scale)
        new_h = int(crop_h * scale)
        crop = cv2.resize(crop, (new_w, new_h), interpolation=cv2.INTER_CUBIC)

    return crop


# ================================================================================
# MODEL SHARING (GPU Memory Optimization)
# ================================================================================
# Eslatma: Multiprocessing da har bir process o'z memory space ga ega,
# shuning uchun to'liq model sharing qiyin. Lekin biz modelni faqat bir marta
# yuklash uchun file lock ishlatamiz va har bir GPU uchun bitta model instance
# yaratamiz (har bir process o'z GPU da modelni yuklaydi, lekin bir xil GPU da
# ishlayotgan kameralar bir xil model instance ni ishlatadi).

def get_model_for_gpu(gpu_id):
    """
    Har bir GPU uchun model yuklaydi.
    
    Eslatma: Multiprocessing da har bir process o'z modelini yuklaydi,
    lekin bir xil GPU da ishlayotgan kameralar bir xil GPU memory ni ishlatadi.
    Bu GPU memory ni tejashga yordam beradi (model weights bir xil GPU memory da).
    
    Agar MODEL_SHARING=True bo'lsa, modelni faqat bir marta yuklash uchun
    file lock ishlatamiz (bu to'liq ishlamaydi, lekin yuklanishni optimallashtiradi).
    """
    if not MODEL_SHARING:
        # Model sharing o'chirilgan bo'lsa, har bir kamera uchun alohida model
        model = YOLO("yolov8n-face.pt")
        model.to(f"cuda:{gpu_id}")
        # FP16 inference vaqtida ishlatiladi (half=True parametri orqali)
        return model
    
    # Model sharing yoqilgan: file lock orqali modelni faqat bir marta yuklash
    import fcntl
    import os
    
    lock_file = f"/tmp/yolo_model_gpu_{gpu_id}.lock"
    model_file = f"/tmp/yolo_model_gpu_{gpu_id}.loaded"
    
    try:
        # File lock orqali modelni faqat bir marta yuklash
        with open(lock_file, 'w') as f:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            
            # Model yuklanganligini tekshirish
            if not os.path.exists(model_file):
                print(f"📦 GPU {gpu_id} uchun model yuklanmoqda (birinchi marta)...")
                
                model = YOLO("yolov8n-face.pt")
                model.to(f"cuda:{gpu_id}")
                # FP16 inference vaqtida ishlatiladi (half=True parametri orqali)
                
                # Model yuklanganligini belgilash
                with open(model_file, 'w') as mf:
                    mf.write("loaded")
                
                print(f"✅ GPU {gpu_id} uchun model yuklandi")
            else:
                # Model allaqachon yuklangan, yangi instance yaratish
                # (lekin bir xil GPU memory ni ishlatadi)
                model = YOLO("yolov8n-face.pt")
                model.to(f"cuda:{gpu_id}")
                # FP16 inference vaqtida ishlatiladi (half=True parametri orqali)
                
                print(f"✅ GPU {gpu_id} uchun model instance yaratildi (shared GPU memory)")
            
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
    except Exception as e:
        # File lock ishlamasa, oddiy model yuklash
        print(f"⚠️ File lock xatosi, oddiy model yuklanmoqda: {e}")
        model = YOLO("yolov8n-face.pt")
        model.to(f"cuda:{gpu_id}")
    
    return model


# ================================================================================
# CAMERA WORKER
# ================================================================================
def camera_worker(camera_id, gpu_id):

    print(f"\n🚀 START WORKER → {camera_id} | GPU {gpu_id}")

    faceid_token = faceid_login()
    hisobot_token = hisobot_login()
    
    if not faceid_token:
        print(f"⚠️ [{camera_id}] FaceID token olinmadi - worker davom etmoqda, keyinroq qayta urinadi")
        # Token None bo'lsa ham worker davom etadi, keyinroq qayta urinadi
    
    if not hisobot_token:
        print(f"❌ [{camera_id}] Hisobot token olinmadi - dastur to'xtatilmoqda")
        return

    last_faceid_token_time = time.time()
    last_hisobot_token_time = time.time()

    last_send_time = 0
    last_identified_time = 0  # Oxirgi marta shaxs muvaffaqiyatli aniqlangan vaqt (cooldown uchun)
    retry_count = 0

    # Load YOLO - Model sharing orqali
    model = get_model_for_gpu(gpu_id)
    print(f"✅ [{camera_id}] Model yuklandi (GPU {gpu_id} - shared)")

    rtsp = RTSP_TEMPLATE.format(camera_id=camera_id)

    person_tracked = False
    person_last_seen = 0
    already_sent = False
    frame_count = 0  # Frame skipping uchun
    tracking_inference_count = 0  # Tracking mode da inference interval uchun
    original_frame = None  # Original frame crop uchun saqlash

    while True:
        try:
            print(f"🔌 Connecting → {camera_id}")
            cap = cv2.VideoCapture(rtsp)

            if not cap.isOpened():
                print(f"⚠️ Cannot open RTSP: {camera_id} (404 yoki boshqa xatolik)")
                print(f"   └─ RTSP URL: {rtsp}")
                print(f"   └─ Kamerani go2rtc.yaml da tekshiring yoki kamera ishlamayapti")
                time.sleep(5)  # 404 xatolik bo'lsa, biroz ko'proq kutamiz
                continue

            print(f"📡 Connected → {camera_id}")

            while True:

                ret, frame = cap.read()
                if not ret:
                    print(f"⚠️ Frame lost → reconnect {camera_id}")
                    break

                frame_count += 1
                now = time.time()
                
                # FRAME SKIPPING OPTIMIZATION
                # Har FRAME_SKIP frameda bir marta detection qilish
                # Bu CPU va GPU yuklamasini kamaytiradi
                if frame_count % FRAME_SKIP != 0:
                    # Frame o'tkazib yuboriladi, lekin tracking mode da person_last_seen yangilanadi
                    if person_tracked:
                        # Agar shaxs bir marta aniqlangan bo'lsa (already_sent = True),
                        # timeout tekshirishni o'tkazib yuboramiz
                        if not already_sent:
                            # Tracking mode da - frame skip qilish, lekin timeout tekshirish
                            # Avval timeout tekshirish, keyin person_last_seen ni yangilash
                            if now - person_last_seen > PERSON_LOST_TIMEOUT:
                                print(f"🔴 [{camera_id}] Odam ketdi ({PERSON_LOST_TIMEOUT}s timeout) — detection qayta yoqildi")
                                person_tracked = False
                                already_sent = False
                                retry_count = 0
                                tracking_inference_count = 0
                            else:
                                # Timeout bo'lmagan, person_last_seen ni yangilash (timeout bo'lmasligi uchun)
                                person_last_seen = now
                        # already_sent = True bo'lsa, timeout tekshirishni o'tkazib yuboramiz
                        # (shaxs bir marta aniqlangan, u kadrda turgan vaqtda qayta aniqlanmaydi)
                    continue

                # TOKEN REFRESH
                if now - last_faceid_token_time > FACEID_REFRESH_TIME:
                    new_token = faceid_login()
                    if new_token:
                        faceid_token = new_token
                        last_faceid_token_time = now
                    # Agar token olinmagan bo'lsa, eski token bilan davom etadi (keyinroq qayta urinadi)

                if now - last_hisobot_token_time > HISOBOT_REFRESH_TIME:
                    new_token = hisobot_login()
                    if new_token:
                        hisobot_token = new_token
                        last_hisobot_token_time = now

                # ==========================================
                # DETECTION MODE
                # ==========================================
                if not person_tracked:
                    # Frame resolutionni kamaytirish (GPU optimallashtirish)
                    original_frame = frame.copy()
                    processing_frame, scale_x, scale_y = resize_frame_for_processing(frame)
                    
                    # Model inference (YOLO thread-safe) - kichikroq frame bilan
                    # FP16 inference vaqtida ishlatiladi (agar USE_HALF_PRECISION=True bo'lsa)
                    # imgsz parametri GPU yuklamasini kamaytiradi (640x360 ga mos)
                    inference_kwargs = {"verbose": False, "imgsz": 640}
                    if USE_HALF_PRECISION:
                        inference_kwargs["half"] = True
                    results = model(processing_frame, **inference_kwargs)

                    best_conf = 0
                    best_box = None

                    for r in results:
                        for box in r.boxes:
                            conf = float(box.conf)
                            if conf < MIN_CONF:
                                continue

                            x1, y1, x2, y2 = map(int, box.xyxy[0])
                            
                            # Box koordinatalarini original frame ga moslashtirish
                            if scale_x != 1.0 or scale_y != 1.0:
                                x1 = int(x1 / scale_x)
                                y1 = int(y1 / scale_y)
                                x2 = int(x2 / scale_x)
                                y2 = int(y2 / scale_y)
                            
                            if (x2-x1) < FACE_MIN_SIZE or (y2-y1) < FACE_MIN_SIZE:
                                continue

                            if conf > best_conf:
                                best_conf = conf
                                best_box = (x1, y1, x2, y2)

                    if not best_box:
                        continue

                    # TRACKING START
                    person_tracked = True
                    already_sent = False
                    retry_count = 0
                    tracking_inference_count = 0
                    person_last_seen = now

                    print(f"🟢 {camera_id}: Yuz topildi – tracking boshlandi")
                    continue

                # ==========================================
                # TRACKING MODE
                # ==========================================
                # Agar shaxs bir marta aniqlangan bo'lsa (already_sent = True), 
                # cooldown o'tgach keyingi shaxsni yuborishga ruxsat beramiz; aks holda
                # faqat yuz topilganini tekshirish va timeout tekshirish
                if already_sent:
                    # Cooldown o'tgach keyingi shaxsni aniqlashga ruxsat berish (ketma-ket barchasini aniqlash)
                    if (now - last_identified_time) >= NEXT_PERSON_COOLDOWN:
                        already_sent = False
                        retry_count = 0
                        print(f"🔄 [{camera_id}] Cooldown tugadi ({NEXT_PERSON_COOLDOWN}s) — keyingi shaxs aniqlanadi")
                    else:
                        # Shaxs aniqlangan, cooldown hali tugamagan — faqat yuz bor-yo'q va timeout tekshirish
                        tracking_inference_count += 1
                    should_inference = (tracking_inference_count % TRACKING_INFERENCE_INTERVAL == 0)
                    
                    if should_inference:
                        # Frame resolutionni kamaytirish (GPU optimallashtirish)
                        original_frame = frame.copy()
                        processing_frame, scale_x, scale_y = resize_frame_for_processing(frame)
                        # FP16 inference vaqtida ishlatiladi (agar USE_HALF_PRECISION=True bo'lsa)
                        inference_kwargs = {"verbose": False, "imgsz": 640}
                        if USE_HALF_PRECISION:
                            inference_kwargs["half"] = True
                        results = model(processing_frame, **inference_kwargs)
                        
                        # Yuz topilganini tekshirish
                        best_box = None
                        for r in results:
                            for box in r.boxes:
                                conf = float(box.conf)
                                if conf < MIN_CONF:
                                    continue
                                
                                x1, y1, x2, y2 = map(int, box.xyxy[0])
                                
                                # Box koordinatalarini original frame ga moslashtirish
                                if scale_x != 1.0 or scale_y != 1.0:
                                    x1 = int(x1 / scale_x)
                                    y1 = int(y1 / scale_y)
                                    x2 = int(x2 / scale_x)
                                    y2 = int(y2 / scale_y)
                                
                                if (x2-x1) < FACE_MIN_SIZE or (y2-y1) < FACE_MIN_SIZE:
                                    continue
                                
                                best_box = (x1, y1, x2, y2)
                                break
                            
                            if best_box:
                                break
                        
                        # Yuz topilgan bo'lsa, person_last_seen yangilanadi (shaxs hali kadrda)
                        if best_box:
                            person_last_seen = now
                        # Yuz topilmagan bo'lsa, person_last_seen yangilanmaydi (timeout tekshirish uchun)
                    
                    # Timeout tekshirish - shaxs haqiqatan ham ketgan bo'lsa
                    if now - person_last_seen > PERSON_LOST_TIMEOUT * 2:  # 2x timeout
                        print(f"🔴 [{camera_id}] Odam haqiqatan ham ketdi ({PERSON_LOST_TIMEOUT * 2}s timeout) — detection qayta yoqildi")
                        person_tracked = False
                        already_sent = False
                        retry_count = 0
                        tracking_inference_count = 0
                    continue

                # Avval timeout tekshirish - odam ketgan bo'lishi mumkin
                if now - person_last_seen > PERSON_LOST_TIMEOUT:
                    print(f"🔴 [{camera_id}] Odam ketdi ({PERSON_LOST_TIMEOUT}s timeout) — detection qayta yoqildi")
                    person_tracked = False
                    already_sent = False
                    retry_count = 0
                    tracking_inference_count = 0
                    continue

                if now - last_send_time < FACEID_SEND_INTERVAL:
                    # Agar inference qilinmasa ham, person_last_seen ni yangilash (timeout bo'lmasligi uchun)
                    # Faqat already_sent = False bo'lsa (shaxs hali aniqlanmagan)
                    if not already_sent:
                        person_last_seen = now
                    continue

                last_send_time = now

                # Tracking mode da inference interval optimallashtirish
                tracking_inference_count += 1
                should_inference = (tracking_inference_count % TRACKING_INFERENCE_INTERVAL == 0)
                
                # Best crop olish
                # Model inference (YOLO thread-safe) - interval bo'yicha
                if should_inference:
                    # Frame resolutionni kamaytirish (GPU optimallashtirish)
                    original_frame = frame.copy()
                    processing_frame, scale_x, scale_y = resize_frame_for_processing(frame)
                    # FP16 inference vaqtida ishlatiladi (agar USE_HALF_PRECENSION=True bo'lsa)
                    # imgsz parametri GPU yuklamasini kamaytiradi (800x450 ga mos)
                    inference_kwargs = {"verbose": False, "imgsz": 640}
                    if USE_HALF_PRECISION:
                        inference_kwargs["half"] = True
                    results = model(processing_frame, **inference_kwargs)
                else:
                    # Inference qilmaymiz, lekin shaxs hali kadrda bo'lishi mumkin
                    # person_last_seen ni yangilash (timeout bo'lmasligi uchun)
                    # Faqat already_sent = False bo'lsa (shaxs hali aniqlanmagan)
                    if not already_sent:
                        person_last_seen = now
                    results = []
                    scale_x, scale_y = 1.0, 1.0
                best_conf = 0
                best_box = None

                for r in results:
                    for box in r.boxes:
                        conf = float(box.conf)
                        if conf < MIN_CONF:
                            continue

                        x1, y1, x2, y2 = map(int, box.xyxy[0])
                        
                        # Box koordinatalarini original frame ga moslashtirish
                        if scale_x != 1.0 or scale_y != 1.0:
                            x1 = int(x1 / scale_x)
                            y1 = int(y1 / scale_y)
                            x2 = int(x2 / scale_x)
                            y2 = int(y2 / scale_y)
                        
                        if (x2-x1) < FACE_MIN_SIZE or (y2-y1) < FACE_MIN_SIZE:
                            continue

                        if conf > best_conf:
                            best_conf = conf
                            best_box = (x1, y1, x2, y2)

                # Yuz topilmasa, person_last_seen yangilanmaydi
                # Lekin agar inference qilinmagan bo'lsa va already_sent = False bo'lsa,
                # person_last_seen allaqachon yangilangan (yuqorida)
                if not best_box:
                    retry_count += 1
                    # Har 5 urinishda bir marta log
                    if retry_count % 5 == 0 or retry_count >= MAX_RETRY - 2:
                        print(f"⚠️ [{camera_id}] Yuz topilmadi (urinish: {retry_count}/{MAX_RETRY})")
                    if retry_count >= MAX_RETRY:
                        print(f"❌ [{camera_id}] {MAX_RETRY} urinishda yuz topilmadi — tracking bekor")
                        person_tracked = False
                        already_sent = False
                        retry_count = 0
                        tracking_inference_count = 0
                    continue

                # Yuz topilganda person_last_seen yangilanadi (crop sifati past bo'lsa ham)
                person_last_seen = now

                # Original frame dan crop olish (yaxshi sifati uchun)
                # Original frame dan crop olish - to'liq resolution (sifatliroq)
                crop_frame = original_frame if original_frame is not None else frame
                crop = crop_quality_face(crop_frame, best_box, enlarge=0.4)  # Ko'proq kontekst uchun 0.4
                if crop is None:
                    retry_count += 1
                    if retry_count % 5 == 0:  # Har 5 urinishda bir marta
                        print(f"⚠️ [{camera_id}] Crop sifati past (blur filter) - {retry_count}/15")
                    # Yuz topilgan, lekin crop sifati past - person_last_seen yangilandi
                    continue

                # Har 3 urinishda bir marta log
                if (retry_count + 1) % 3 == 0 or retry_count == 0:
                    print(f"📤 [{camera_id}] FaceID ga yuborilmoqda (urinish: {retry_count+1}/15)")

                res = send_to_faceid(faceid_token, crop, camera_id)

                if res and res.get("error") == "unauthorized":
                    print(f"🔄 [{camera_id}] Token yangilanmoqda...")
                    new_token = faceid_login()
                    if new_token:
                        faceid_token = new_token
                        last_faceid_token_time = now
                    # Agar token olinmagan bo'lsa, keyingi safar qayta urinadi
                    continue

                # Shaxs aniqlanganini tekshirish - status "success" yoki "data" mavjud bo'lsa
                if res and res.get("data") and res.get("data").get("person"):
                    # Shaxs ma'lumotlari mavjud
                    person = res["data"]["person"]
                    
                    # JSHShIR va ism ma'lumotlarini tekshirish
                    if "jshshir" in person:
                        retry_count = 0
                        already_sent = True
                        last_identified_time = now  # Cooldown boshlanishi (keyingi shaxs uchun)

                        jshshir = person["jshshir"]
                        
                        # To'liq ism yasash: first_name, last_name, middle_name
                        first_name = person.get("first_name", "")
                        last_name = person.get("last_name", "")
                        middle_name = person.get("middle_name", "")
                        
                        # To'liq ism yasash
                        full_name_parts = [part for part in [last_name, first_name, middle_name] if part]
                        full_name = " ".join(full_name_parts) if full_name_parts else "Noma'lum"
                        
                        # Shaxs ma'lumotlarini ko'rsatish
                        print(f"🟢 [{camera_id}] SHAXS ANIQLANDI:")
                        print(f"   └─ JSHSHIR: {jshshir}")
                        print(f"   └─ Ism: {full_name}")
                        print(f"   └─ First name: {first_name}")
                        print(f"   └─ Last name: {last_name}")
                        print(f"   └─ Middle name: {middle_name}")

                        # IP formatni to'g'rilash: 192_168_1_211 -> 192.168.1.211
                        camera_ip = camera_id.replace("_", ".")
                        print(f"📤 [{camera_id}] Hisobot API ga yuborilmoqda:")
                        print(f"   └─ IP: {camera_ip}")
                        print(f"   └─ JSHSHIR: {jshshir}")
                        print(f"   └─ BranchID: {HISOBOT_BRANCH_ID}")

                        hs_res = send_to_hisobot(hisobot_token, jshshir, camera_ip)
                        if hs_res:
                            if hs_res.get("error") == "unauthorized":
                                print(f"🔄 [{camera_id}] Hisobot token yangilanmoqda...")
                                new_token = hisobot_login()
                                if new_token:
                                    hisobot_token = new_token
                                    last_hisobot_token_time = now
                                else:
                                    print(f"⚠️ [{camera_id}] Hisobot token yangilash muvaffaqiyatsiz")
                            # Muvaffaqiyatli javob allaqachon log qilingan (send_to_hisobot ichida)
                        else:
                            print(f"⚠️ [{camera_id}] Hisobotga yozishda muammo (javob None)")
                    else:
                        # JSHShIR yo'q
                        retry_count += 1
                        print(f"⚠️ [{camera_id}] JSHShIR mavjud emas: {list(person.keys())} ({retry_count}/15)")
                elif res and res.get("status") == "success":
                    # Eski format uchun qo'llab-quvvatlash (full_name mavjud bo'lsa)
                    if res.get("data") and res.get("data").get("person"):
                        person = res["data"]["person"]
                        
                        if "jshshir" in person:
                            jshshir = person["jshshir"]
                            
                            # full_name mavjud bo'lsa ishlatish, aks holda yasash
                            if "full_name" in person:
                                full_name = person["full_name"]
                            else:
                                first_name = person.get("first_name", "")
                                last_name = person.get("last_name", "")
                                middle_name = person.get("middle_name", "")
                                full_name_parts = [part for part in [last_name, first_name, middle_name] if part]
                                full_name = " ".join(full_name_parts) if full_name_parts else "Noma'lum"

                            retry_count = 0
                            already_sent = True
                            last_identified_time = now  # Cooldown boshlanishi (keyingi shaxs uchun)

                            print(f"🟢 [{camera_id}] SHAXS ANIQLANDI: {full_name} (JSHSHIR: {jshshir})")

                            # IP formatni to'g'rilash
                            camera_ip = camera_id.replace("_", ".")
                            print(f"📤 [{camera_id}] Hisobot API ga yuborilmoqda: IP={camera_ip}, JSHSHIR={jshshir}, BranchID={HISOBOT_BRANCH_ID}")

                            hs_res = send_to_hisobot(hisobot_token, jshshir, camera_ip)
                            if hs_res:
                                if hs_res.get("error") == "unauthorized":
                                    print(f"🔄 [{camera_id}] Hisobot token yangilanmoqda...")
                                    new_token = hisobot_login()
                                    if new_token:
                                        hisobot_token = new_token
                                        last_hisobot_token_time = now
                                    else:
                                        print(f"⚠️ [{camera_id}] Hisobot token yangilash muvaffaqiyatsiz")
                            else:
                                print(f"⚠️ [{camera_id}] Hisobotga yozishda muammo (javob None)")
                        else:
                            retry_count += 1
                            print(f"⚠️ [{camera_id}] JSHShIR mavjud emas ({retry_count}/15)")
                    else:
                        retry_count += 1
                        print(f"⚠️ [{camera_id}] Status success, lekin shaxs ma'lumotlari yo'q ({retry_count}/15)")
                else:
                    retry_count += 1
                    # Har 3 urinishda bir marta yoki oxirgi urinishlarda log
                    if retry_count % 3 == 0 or retry_count >= 12:
                        if res is None:
                            print(f"⚠️ [{camera_id}] FaceID API javob qaytarmadi ({retry_count}/15)")
                        else:
                            status = res.get("status", "unknown")
                            message = res.get("message", "No message")
                            print(f"⚠️ [{camera_id}] Aniqlanmadi: status={status}, message={message} ({retry_count}/15)")

                if retry_count >= MAX_RETRY:
                    print(f"❌ [{camera_id}] Maksimal {MAX_RETRY} urinish tugadi — tracking reset")
                    person_tracked = False
                    already_sent = False
                    retry_count = 0
                    tracking_inference_count = 0

        except Exception as e:
            print(f"❌ WORKER ERROR → {camera_id}")
            traceback.print_exc()

        print(f"♻️ Reconnecting in 1s → {camera_id}")
        time.sleep(1)



# ================================================================================
# SYNC CAMERAS FROM DATABASE
# ================================================================================
def sync_cameras_from_db():
    """
    Bazadan kameralarni o'qib, go2rtc.yaml ga yozadi
    """
    print("🔄 Bazadan kameralarni sinxronlash...")
    try:
        # sync_cameras_from_db.py skriptini ishga tushirish
        result = subprocess.run(
            [sys.executable, "sync_cameras_from_db.py"],
            capture_output=True,
            text=True,
            timeout=30
        )
        
        if result.returncode == 0:
            print(result.stdout)
            return True
        else:
            print(f"⚠️  Bazadan kameralarni sinxronlashda xatolik:")
            print(result.stderr)
            return False
    except subprocess.TimeoutExpired:
        print("❌ Bazadan kameralarni sinxronlash vaqt tugadi (30s)")
        return False
    except Exception as e:
        print(f"❌ Bazadan kameralarni sinxronlashda xatolik: {e}")
        return False


# ================================================================================
# MAIN
# ================================================================================
def main():
    # Dastlab bazadan kameralarni sinxronlash
    print("=" * 60)
    print("🚀 Dastur ishga tushmoqda...")
    print("=" * 60)
    
    sync_success = sync_cameras_from_db()
    
    if not sync_success:
        print("⚠️  Bazadan kameralarni sinxronlash muvaffaqiyatsiz bo'ldi.")
        print("   enabled_cameras.txt faylidan kameralar o'qiladi...")
    
    # Kameralarni enabled_cameras.txt dan o'qish
    cams = []
    try:
        with open("enabled_cameras.txt") as f:
            cams = [x.strip() for x in f if x.strip()]
    except FileNotFoundError:
        print("❌ enabled_cameras.txt fayli topilmadi!")
        print("   Iltimos, enabled_cameras.txt faylini yarating va ishlatmoqchi bo'lgan kameralarni qo'shing.")
        print("   Har bir kamera IP manzili alohida qatorda bo'lishi kerak (masalan: 192_168_1_211)")
        return
    
    if not cams:
        print("❌ Hech qanday kamera topilmadi!")
        return

    print("🎯 Enabled cameras:", cams)
    print(f"⚙️  Optimizatsiya parametrlari (shaxs aniqlash tezligi optimallashtirildi):")
    print(f"   └─ Model sharing: {MODEL_SHARING}")
    print(f"   └─ Frame skip: {FRAME_SKIP} (har {FRAME_SKIP} frameda bir marta detection)")
    print(f"   └─ Processing resolution: {PROCESSING_WIDTH}x{PROCESSING_HEIGHT}")
    print(f"   └─ Half precision (FP16): {USE_HALF_PRECISION}")
    print(f"   └─ Tracking inference interval: {TRACKING_INFERENCE_INTERVAL} (har {TRACKING_INFERENCE_INTERVAL} frameda bir marta)")
    print(f"   └─ Keyingi shaxs cooldown: {NEXT_PERSON_COOLDOWN}s (ketma-ket barcha shaxslar aniqlanadi)")
    print(f"   └─ YOLO imgsz: 640 (model input size optimallashtirildi)")
    if MODEL_SHARING:
        print("   └─ GPU memory: Har bir GPU uchun bitta model (6-10x tejash)")
    if USE_HALF_PRECISION:
        print("   └─ GPU yuklama: FP16 precision (~50% kamaytirish)")
    if PROCESSING_WIDTH and PROCESSING_HEIGHT:
        print(f"   └─ GPU yuklama: Frame resolution {PROCESSING_WIDTH}x{PROCESSING_HEIGHT} ga kamaytiriladi")
        print(f"   └─ GPU yuklama: Frame skip {FRAME_SKIP} (~{int((1-1/FRAME_SKIP)*100)}% kamaytirish)")
        print(f"   └─ GPU yuklama: Tracking interval {TRACKING_INFERENCE_INTERVAL} (~{int((1-1/TRACKING_INFERENCE_INTERVAL)*100)}% kamaytirish)")

    jobs = []
    # Faqat soz holatdagi GPU lar ro'yxati (GPU_IDS bo'sh bo'lsa, barcha GPU lar ishlatiladi)
    if GPU_IDS:
        gpu_list = GPU_IDS
    else:
        gpu_list = list(range(max(1, torch.cuda.device_count())))
    print(f"🎛 Foydalaniladigan GPU lar: {gpu_list}")

    # Worker'larni bosqichma-bosqich ishga tushirish (FaceID API overload qilmaslik uchun)
    WORKER_START_DELAY = 0.5  # Har bir worker orasida 0.5 sekund kutish
    
    for idx, cam in enumerate(cams):
        # Faqat ruxsat berilgan GPU lar bo'yicha taqsimlash
        gpu_id = gpu_list[idx % len(gpu_list)]
        p = Process(target=camera_worker, args=(cam, gpu_id))
        p.start()
        jobs.append(p)
        
        # Har bir worker orasida kichik delay (FaceID API server'ni overload qilmaslik uchun)
        if idx < len(cams) - 1:  # Oxirgi worker uchun delay kerak emas
            time.sleep(WORKER_START_DELAY)

    for j in jobs:
        j.join()


if __name__ == "__main__":
    main()