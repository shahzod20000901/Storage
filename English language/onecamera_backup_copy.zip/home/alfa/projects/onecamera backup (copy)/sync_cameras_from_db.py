#!/usr/bin/env python3
"""
Bazadan kameralarni o'qib, go2rtc.yaml fayliga yozish
"""
import asyncio
import asyncpg
import yaml
import os
from urllib.parse import quote

# Database connection
DATABASE_URL = "postgresql+asyncpg://chirchiq:shahzod2707@localhost:5432/chirchiq"

# go2rtc.yaml fayl yo'li
GO2RTC_YAML_PATH = "go2rtc.yaml"
ENABLED_CAMERAS_PATH = "enabled_cameras.txt"


async def get_cameras_from_db():
    """
    Bazadan barcha kameralarni o'qib oladi
    """
    # Database URL dan connection parametrlarini ajratib olish
    # Format: postgresql+asyncpg://user:password@host:port/database
    url_parts = DATABASE_URL.replace("postgresql+asyncpg://", "").split("@")
    auth = url_parts[0].split(":")
    host_port_db = url_parts[1].split("/")
    host_port = host_port_db[0].split(":")
    
    user = auth[0]
    password = auth[1]
    host = host_port[0]
    port = int(host_port[1]) if len(host_port) > 1 else 5432
    database = host_port_db[1]
    
    conn = await asyncpg.connect(
        host=host,
        port=port,
        user=user,
        password=password,
        database=database
    )
    
    try:
        # cameras jadvalidan barcha kameralarni o'qish
        # Avval jadval strukturasini tekshirish
        try:
            rows = await conn.fetch("""
                SELECT 
                    id, 
                    ip, 
                    login, 
                    password, 
                    port,
                    stream_type,
                    channel,
                    camera_type
                FROM cameras
                ORDER BY ip
            """)
        except Exception as e:
            # Agar stream_type, channel, camera_type ustunlari bo'lmasa
            print(f"⚠️  Ba'zi ustunlar topilmadi, oddiy so'rov ishlatilmoqda: {e}")
            try:
                rows = await conn.fetch("""
                    SELECT 
                        id, 
                        ip, 
                        login, 
                        password, 
                        port
                    FROM cameras
                    ORDER BY ip
                """)
            except Exception as e2:
                # Agar login ham bo'lmasa, faqat asosiy ustunlar
                print(f"⚠️  login ustuni ham topilmadi, minimal so'rov ishlatilmoqda: {e2}")
                rows = await conn.fetch("""
                    SELECT 
                        id, 
                        ip, 
                        password
                    FROM cameras
                    ORDER BY ip
                """)
        
        cameras = []
        for row in rows:
            # login yoki username ni topish
            username = row.get('login') or row.get('username') or 'admin'
            password = row.get('password') or 'admin123'
            port = row.get('port') or 554
            
            camera = {
                'id': row['id'],
                'ip': row['ip'],
                'username': username,
                'password': password,
                'port': port,
            }
            
            # Agar ustunlar mavjud bo'lsa, ularni qo'shish
            if 'stream_type' in row:
                camera['stream_type'] = row['stream_type'] or 'main'  # Default: main stream
            else:
                camera['stream_type'] = 'main'  # Default: main stream
            
            if 'channel' in row:
                camera['channel'] = row['channel'] or 1
            else:
                camera['channel'] = 1
            
            if 'camera_type' in row:
                camera['camera_type'] = (row['camera_type'] or 'dahua').lower()
            else:
                # IP ga qarab aniqlash (Hikvision odatda ma'lum IP range da)
                # Yoki default Dahua
                camera['camera_type'] = 'dahua'
            
            cameras.append(camera)
        
        return cameras
    finally:
        await conn.close()


def build_rtsp_url(camera):
    """
    Kameradan RTSP URL yaratadi
    """
    ip = camera['ip']
    username = camera['username']
    password = camera['password']
    port = camera['port']
    stream_type = camera.get('stream_type', 'main')
    channel = camera.get('channel', 1)
    camera_type = camera.get('camera_type', 'dahua').lower()
    
    # Username va password ni URL encode qilish
    username_encoded = quote(username)
    password_encoded = quote(password)
    
    if camera_type == 'hikvision':
        # Hikvision kameralar uchun
        if stream_type == 'sub':
            # Substream: /Streaming/Channels/102
            rtsp_url = f"rtsp://{username_encoded}:{password_encoded}@{ip}:{port}/Streaming/Channels/102"
        else:
            # Main stream: /Streaming/Channels/101
            rtsp_url = f"rtsp://{username_encoded}:{password_encoded}@{ip}:{port}/Streaming/Channels/101"
    else:
        # Dahua kameralar uchun (default)
        if stream_type == 'sub':
            # Substream: subtype=1
            rtsp_url = f"rtsp://{username_encoded}:{password_encoded}@{ip}:{port}/cam/realmonitor?channel={channel}&subtype=1"
        else:
            # Main stream: subtype=0
            rtsp_url = f"rtsp://{username_encoded}:{password_encoded}@{ip}:{port}/cam/realmonitor?channel={channel}&subtype=0"
    
    return rtsp_url


def generate_go2rtc_yaml(cameras):
    """
    go2rtc.yaml faylini yaratadi
    """
    config = {
        'api': {
            'listen': ':1984'
        },
        'rtsp': {
            'listen': ':8554'
        },
        'streams': {}
    }
    
    # Har bir kamera uchun stream qo'shish
    for camera in cameras:
        # Camera ID: IP ni underscore bilan almashtirish (192.168.1.10 -> 192_168_1_10)
        camera_id = camera['ip'].replace('.', '_')
        rtsp_url = build_rtsp_url(camera)
        
        config['streams'][camera_id] = rtsp_url
    
    return config


async def main():
    """
    Asosiy funksiya
    """
    print("🔌 Bazaga ulanmoqda...")
    
    try:
        cameras = await get_cameras_from_db()
        print(f"✅ Bazadan {len(cameras)} ta kamera topildi")
        
        if not cameras:
            print("⚠️  Hech qanday kamera topilmadi!")
            return
        
        # go2rtc.yaml yaratish
        print(f"📝 go2rtc.yaml faylini yaratmoqda...")
        config = generate_go2rtc_yaml(cameras)
        
        # go2rtc.yaml faylga yozish
        with open(GO2RTC_YAML_PATH, 'w') as f:
            yaml.dump(config, f, default_flow_style=False, sort_keys=False, allow_unicode=True)
        
        print(f"✅ go2rtc.yaml fayli yaratildi: {GO2RTC_YAML_PATH}")
        print(f"   └─ {len(config['streams'])} ta stream qo'shildi")
        
        # enabled_cameras.txt faylga YOZILMAYDI - faqat foydalanuvchi tomonidan ko'rsatilgan kameralar saqlanadi
        print(f"ℹ️  enabled_cameras.txt fayli o'zgartirilmaydi (faqat foydalanuvchi tomonidan ko'rsatilgan kameralar saqlanadi)")
        
        # Bir nechta kamera misollari ko'rsatish
        print("\n📋 Stream misollari:")
        for i, (camera_id, rtsp_url) in enumerate(list(config['streams'].items())[:5]):
            print(f"   {camera_id}: {rtsp_url}")
        if len(config['streams']) > 5:
            print(f"   ... va yana {len(config['streams']) - 5} ta kamera")
        
    except Exception as e:
        print(f"❌ Xatolik: {e}")
        import traceback
        traceback.print_exc()


if __name__ == "__main__":
    asyncio.run(main())
