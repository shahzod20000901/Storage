#!/bin/bash
# API server ni ishga tushirish skripti

cd "$(dirname "$0")"

# Virtual environment ni faollashtirish
source venv/bin/activate

# API serverni ishga tushirish
echo "🚀 API server ishga tushmoqda..."
echo "   Port: 8000"
echo "   Endpoint: http://0.0.0.0:8000"
echo "   Docs: http://0.0.0.0:8000/docs"
echo ""

python api_server.py
