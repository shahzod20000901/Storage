import time
import psutil
from rich.live import Live
from rich.table import Table
from rich.panel import Panel
from rich.layout import Layout
from rich.console import Console
from rich import box

# ---------------- GPU INIT ----------------
try:
    from pynvml import *
    nvmlInit()
    GPU_AVAILABLE = True
except Exception as e:
    print("GPU INIT ERROR:", e)
    GPU_AVAILABLE = False

console = Console()

# ---------------- GPU INFO (ALL GPUs) ----------------
def get_gpu_info():
    if not GPU_AVAILABLE:
        return []

    gpu_list = []
    device_count = nvmlDeviceGetCount()

    for i in range(device_count):
        handle = nvmlDeviceGetHandleByIndex(i)
        util = nvmlDeviceGetUtilizationRates(handle)
        mem = nvmlDeviceGetMemoryInfo(handle)
        temp = nvmlDeviceGetTemperature(handle, NVML_TEMPERATURE_GPU)

        # GPU processes
        try:
            processes = nvmlDeviceGetComputeRunningProcesses(handle)
        except:
            processes = []

        proc_info = []
        for p in processes:
            proc_info.append({
                "pid": p.pid,
                "mem": p.usedGpuMemory / (1024 * 1024)
            })

        gpu_list.append({
            "id": i,
            "util": util.gpu,
            "mem_percent": (mem.used / mem.total) * 100,
            "temp": temp,
            "processes": proc_info
        })

    return gpu_list


# ---------------- NETWORK ----------------
def get_net_speed(prev, prev_time):
    current = psutil.net_io_counters()
    now = time.time()
    time_diff = now - prev_time

    upload = (current.bytes_sent - prev.bytes_sent) / (1024*1024) / time_diff
    download = (current.bytes_recv - prev.bytes_recv) / (1024*1024) / time_diff

    return current, now, upload, download


# ---------------- DISK ----------------
def get_disk_speed(prev, prev_time):
    current = psutil.disk_io_counters()
    now = time.time()
    time_diff = now - prev_time

    read_speed = (current.read_bytes - prev.read_bytes) / (1024*1024) / time_diff
    write_speed = (current.write_bytes - prev.write_bytes) / (1024*1024) / time_diff

    return current, now, read_speed, write_speed


# ---------------- TOP CPU PROCESSES ----------------
def get_top_processes():
    procs = []
    for p in psutil.process_iter(['pid', 'name', 'cpu_percent']):
        try:
            procs.append(p.info)
        except:
            pass

    procs = sorted(procs, key=lambda x: x['cpu_percent'], reverse=True)
    return procs[:5]


# ---------------- DASHBOARD ----------------
def build_dashboard(prev_net, prev_net_time, prev_disk, prev_disk_time):

    cpu_per_core = psutil.cpu_percent(percpu=True)
    cpu_avg = sum(cpu_per_core) / len(cpu_per_core)
    ram = psutil.virtual_memory()
    swap = psutil.swap_memory()
    load = psutil.getloadavg()
    process_count = len(psutil.pids())

    # Network
    prev_net, prev_net_time, upload, download = get_net_speed(prev_net, prev_net_time)

    # Disk
    prev_disk, prev_disk_time, read_speed, write_speed = get_disk_speed(prev_disk, prev_disk_time)

    gpu_list = get_gpu_info()
    top_procs = get_top_processes()

    layout = Layout()

    # -------- MAIN TABLE --------
    main_table = Table(title="🚀 DAVOMAT SERVER PROFESSIONAL MONITOR", box=box.ROUNDED)
    main_table.add_column("Metric", justify="left")
    main_table.add_column("Value", justify="right")

    main_table.add_row("CPU Avg", f"{cpu_avg:.1f}%")
    main_table.add_row("RAM", f"{ram.percent}%")
    main_table.add_row("SWAP", f"{swap.percent}%")
    main_table.add_row("Load Avg (1m)", f"{load[0]:.2f}")
    main_table.add_row("Processes", str(process_count))
    main_table.add_row("Net Upload", f"{upload:.2f} MB/s")
    main_table.add_row("Net Download", f"{download:.2f} MB/s")
    main_table.add_row("Disk Read", f"{read_speed:.2f} MB/s")
    main_table.add_row("Disk Write", f"{write_speed:.2f} MB/s")

    # -------- GPU TABLE --------
    gpu_table = Table(title="🎮 GPU STATUS (ALL CARDS)", box=box.ROUNDED)
    gpu_table.add_column("GPU")
    gpu_table.add_column("Util %")
    gpu_table.add_column("Mem %")
    gpu_table.add_column("Temp °C")
    gpu_table.add_column("Running Processes")

    if gpu_list:
        for g in gpu_list:
            proc_text = ""
            for p in g["processes"]:
                proc_text += f"PID {p['pid']} ({p['mem']:.0f}MB)\n"

            if not proc_text:
                proc_text = "Idle"

            gpu_table.add_row(
                str(g["id"]),
                f"{g['util']}%",
                f"{g['mem_percent']:.1f}%",
                f"{g['temp']}",
                proc_text
            )
    else:
        gpu_table.add_row("No GPU", "-", "-", "-", "-")

    # -------- CPU PROCESS TABLE --------
    proc_table = Table(title="🔥 TOP 5 CPU Processes", box=box.MINIMAL)
    proc_table.add_column("PID")
    proc_table.add_column("Name")
    proc_table.add_column("CPU %")

    for p in top_procs:
        proc_table.add_row(str(p['pid']), str(p['name']), str(p['cpu_percent']))

    layout.split_column(
        Layout(Panel(main_table), size=12),
        Layout(Panel(gpu_table), size=15),
        Layout(Panel(proc_table))
    )

    return layout, prev_net, prev_net_time, prev_disk, prev_disk_time


# ---------------- MAIN ----------------
def main():
    prev_net = psutil.net_io_counters()
    prev_net_time = time.time()

    prev_disk = psutil.disk_io_counters()
    prev_disk_time = time.time()

    psutil.cpu_percent(interval=None)

    with Live(refresh_per_second=1, screen=True) as live:
        while True:
            layout, prev_net, prev_net_time, prev_disk, prev_disk_time = build_dashboard(
                prev_net, prev_net_time, prev_disk, prev_disk_time
            )
            live.update(layout)
            time.sleep(1)


if __name__ == "__main__":
    main()
